// src/components/TodoApp.js
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import TodoList from './TodoList';
import TodoForm from './TodoForm';
import TodoUpdateForm from './TodoUpdateForm';
import './TodoApp.css';
import axois from 'axios'

const TodoApp = () => {
    const [todos, setTodos] = useState([]);
    const [currentTodo, setCurrentTodo] = useState(null);

    useEffect(() => {
        axois.get('http://127.0.0.1:3000/api/todos/read').then((res)=>{
            setTodos(res.data)
        }).catch((err)=>{
            console.log("Something went wrong...")
        })            
    }, []);

    const addTodo = (title, description) => {
        const newTodo = {
            userId: 1,
            id: todos.length + 1,
            title: title,
            description: description,
            completed: false,
        };
        setTodos([newTodo, ...todos]);
    };

    const updateTodo = (id, updatedTitle, updatedDescription) => {
        setTodos(todos.map(todo =>
            todo.id === id ? { ...todo, title: updatedTitle, description: updatedDescription } : todo
        ));
    };

    const deleteTodo = (id) => {
        setTodos(todos.filter(todo => todo.id !== id));
    };

    const toggleComplete = (id) => {
        setTodos(todos.map(todo =>
            todo.id === id ? { ...todo, completed: !todo.completed } : todo
        ));
    };

    return (
        <Router>
            <div className="todo-app">
                <h1>Todo List</h1>
                <Routes>
                    <Route path="/" element={<TodoList todos={todos} toggleComplete={toggleComplete} deleteTodo={deleteTodo} setCurrentTodo={setCurrentTodo} />} />
                    <Route path="/add" element={<TodoForm addTodo={addTodo} />} />
                    <Route path="/edit/:id" element={<TodoUpdateForm currentTodo={currentTodo} updateTodo={updateTodo} />} />
                </Routes>
            </div>
        </Router>
    );
};

export default TodoApp;
